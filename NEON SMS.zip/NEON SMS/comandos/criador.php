<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @neonsmsbot \n\n ▫️ · SUPORTE: @suplinux</b>",
	'parse_mode' => 'html'
]);