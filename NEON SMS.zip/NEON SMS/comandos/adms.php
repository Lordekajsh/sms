<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Olá meus adms disponível no momento são\n @suplinux e @suleimansuporte</b>",
	'parse_mode' => 'html'
]);