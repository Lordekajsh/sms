<?php

if ($tlg->Callback_ID () !== null){
	
	// encerra carregamento do botão de callback
	$tlg->answerCallbackQuery ([
		'callback_query_id' => $tlg->Callback_ID ()
	]);

}
$id_pagamento = $pagamento ['id'];
$bonus = (BONUS == 0) ? '' : '<em><u>+'.BONUS.'% bônus</u></em>';
$valor_pagamento = 11;

if (isset ($complemento)){

	// pega valor e tipo de calculo
	@list ($valor, $calculo) = explode (' ', $complemento);

	switch ($calculo) {
		case "+1":

		$valor_pagamento = ++$valor;

			break;

		case "+10":

		$valor_pagamento = $valor+10;

			break;

		case "-10":

		$valor_pagamento = $valor-10;

			break;
		
		case "-1":

			case "-50":

				$valor_pagamento = $valor-50;
		
					break;
					case "+50":

						$valor_pagamento = $valor+50;
				
							break;

		$valor_pagamento = --$valor;

			break;
	}

	// checagem de valor abaixo do mínimo
	if ($valor_pagamento < 11){
		$valor_pagamento = 11;
	}

}

$dados_mensagem = [
	'chat_id' => $tlg->ChatID (),
	'text' => "🗣️ Para que serve esse bot?
No nosso serviço você tem a capacidade de receber SMS de números virtuais virgens.
Casos de uso:
Crie contas verificadas por telefone sem precisar usar o seu número real, proteja-se de sites fraudulentos que precisam inserir seu número para baixar arquivos ou usar um serviço; Impeça spam de SMS usando nosso números descartaveis em sites e apps.

💠 Como conseguir um número?
Use o comando /servicos e veja os serviços disponiveis.
Você irá receber um número temporário para receber sms, assim conseguirá criar contas como telegram e whatsapp novos, também em apps, iFood, 99app, Kwai entre outros

💠 Como colocar saldo na minha conta?
Use o comando /recarregar e escolha o valor, após o pagamento o saldo é adicionado automaticamente na sua conta.

⚠️ Termos de uso:
Em caso de quaisquer tipo de abusos no uso do bot você pode ser penalizado com bloqueio ou redução no seu saldo atual, esses termos entram em vigor apartir do momento em que você iniciou o bot.
É proibida autilização do serviço para quaisquer fins ilegais, bem como não realizar uso para ações que prejudiquem o serviço ou terceiros, também é proibido o uso do serviço para assinaturas pagas.
Devoluções somente em até 1h após a compra e não pode pode ter tido uso do saldo comprado.

👉 Suporte @suplinux
💬 Canal @Neonglock",
	'parse_mode' => 'html',
	'message_id' => $tlg->MessageID (),
	'disable_web_page_preview' => 'true',
	'reply_markup' => $tlg->buildInlineKeyboard ([
		[
			$tlg->buildInlineKeyBoardButton ("✔️Aceito✔️", null, "/start"),
                        $tlg->buildInlineKeyBoardButton ("❌Nao aceito❌", null, "/ajuda")
                 ],
	])
];

if ($tlg->Callback_ID () !== null){

	$tlg->editMessageText ($dados_mensagem);

}else {

	$tlg->sendMessage ($dados_mensagem);

}